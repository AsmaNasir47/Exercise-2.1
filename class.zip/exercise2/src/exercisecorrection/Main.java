package exercisecorrection;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		classiPhone smartphone = new classiPhone();
		smartphone.printMakeCall();
		smartphone.printPhone();
		smartphone.printPlayGame();
		
		classHuawei smartphone1 = new classHuawei();
		smartphone1.printMakeCall();
		smartphone1.printPhone();
		smartphone1.printPlayGame();
 
	}

}
