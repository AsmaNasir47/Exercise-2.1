package exercisecorrection;

public class classiPhone {

	String phone = "iPhone"; 
	String makecall = "make a call";
	String playgame = "play games";
		
		void printPhone() {
			System.out.println(phone);
		}
		void printMakeCall() {
			System.out.println(makecall);
		}
		void printPlayGame() {
			System.out.println(playgame);
		}
}
